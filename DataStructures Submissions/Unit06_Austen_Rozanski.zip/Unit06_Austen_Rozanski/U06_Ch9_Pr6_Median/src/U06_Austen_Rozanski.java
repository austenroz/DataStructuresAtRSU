/**
 * 
 * Author: Austen Rozanski
 * Class: Data Structures
 * Title: Median
 * 
 * Date Started: February 21, 2015
 * Date Last Revised: February 21, 2015
 * 
 * 
 * Description of Problem: Write a program that finds the median using recursion without sorting
 * 
 * 
 */ 

public class U06_Austen_Rozanski {

	public static void main(String[] args) {

       int[] input = {24,2,45,20,56,75,2,56,99,53,12};
       Median.findMedian(input);
	}
}