
public class Ball 
{
	private int number;
	
	public Ball(int number)
	{
		this.setNumber(number);
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
}
